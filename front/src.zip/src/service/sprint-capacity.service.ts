import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { format } from 'date-fns';

export interface SprintCapacity {
  idDevelopper: number;
  nom: string;
  prenom: string;
  capaciteStoryPoints: number;
}

@Injectable({ providedIn: 'root' })
export class SprintCapacityService {
  private baseUrl = '/api/sprint-capacity';

  constructor(private http: HttpClient) {}

  getCapacity(start: Date, end: Date) {
    const startStr = format(start, 'yyyy-MM-dd');
    const endStr = format(end, 'yyyy-MM-dd');
    return this.http.get<SprintCapacity[]>(`${this.baseUrl}?start=${startStr}&end=${endStr}`);
  }
}