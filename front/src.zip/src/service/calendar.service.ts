// src/app/service/calendar.service.ts
import { Injectable } from '@angular/core';

import { HolidayService } from './HolidayService';

import { Resource } from '../model/Resource';
import { DateCalendar } from '../app/calendar/calendar.component';


export interface EventSpan {
  date: DateCalendar;
  colspan: number;
}

@Injectable({
  providedIn: 'root',
})
export class CalendarService {
  constructor(private holidayService: HolidayService) {}

  getDatesOfMonth(year: number, month: number): DateCalendar[] {
    const daysInMonth = new Date(year, month, 0).getDate();
    const holidays = this.holidayService.getHolidays(year);
    const dates: DateCalendar[] = [];
    for (let day = 1; day <= daysInMonth; day++) {
      dates.push(new DateCalendar(holidays, year, month - 1, day));
    }
    return dates;
  }

  isResourceInactiveWholeMonth(resource: Resource, dates: DateCalendar[]): boolean {
    return dates.every((date) => date.isInactif(resource));
  }

buildEventSpans(
  calendarVos: { dates: DateCalendar[] }[],
  resources: Resource[]
): Map<string, Map<number, EventSpan[]>> {
  const eventSpansMap = new Map<string, Map<number, EventSpan[]>>();

  for (let resource of resources) {
    const resourceMap = new Map<number, EventSpan[]>();

    calendarVos.forEach((calendarVo, monthIdx) => {
      const spans: EventSpan[] = [];
      const dates = calendarVo.dates;

      // Fonction utilitaire pour savoir si date2 est le jour suivant date1
      const isNextDay = (date1: DateCalendar, date2: DateCalendar) => {
        const d1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
        const d2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
        const diff = (d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24);
        return diff === 1;
      };

      let i = 0;
      while (i < dates.length) {
        const currentDate = dates[i];

        if (currentDate.isEvent(resource)) {
          let spanStart = i;
          let spanLength = 1;

          while (
            i + 1 < dates.length &&
            dates[i + 1].isEvent(resource) &&
            isNextDay(dates[i], dates[i + 1])
          ) {
            spanLength++;
            i++;
          }

          spans.push({
            date: currentDate,
            colspan: spanLength,
          });

          // Pour les cellules du span à colspan=0 (fusionnées)
          for (let j = 1; j < spanLength; j++) {
            spans.push({
              date: dates[spanStart + j],
              colspan: 0,
            });
          }

          i++;
        } else {
          spans.push({
            date: currentDate,
            colspan: 1,
          });
          i++;
        }
      }

      resourceMap.set(monthIdx, spans);
    });

    eventSpansMap.set(resource.prenomResource, resourceMap);
  }

  return eventSpansMap;
}



}


