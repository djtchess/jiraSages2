import { Component, inject, model, QueryList, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CommonModule, DatePipe, formatDate } from '@angular/common';
import { Event, Month, Resource, Holiday } from '../../model/Resource';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
  MAT_DATE_FORMATS,
  MAT_NATIVE_DATE_FORMATS,
  provideNativeDateAdapter,
} from '@angular/material/core';
import { HolidayService } from '../../service/HolidayService';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
  MatDialogModule,
} from '@angular/material/dialog';
import { ResourceService } from '../../service/resource.service';
import { EventService } from '../../service/event.service';
import { CalendarVO } from '../../model/CalendarVO';
import { CalendarService } from '../../service/calendar.service';
import { ElementRef, ViewChild } from '@angular/core';
import html2pdf from 'html2pdf.js';
import { OverlayContainer } from '@angular/cdk/overlay';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css', 'calendar.component.dark-mode.scss' ],
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    FormsModule,
    DatePipe,
    MatIconModule,
    MatDividerModule,
    MatButtonModule,
    CommonModule,
  ],
})
export class CalendarComponent {

  @ViewChild('monthDivs') monthDivs!: QueryList<ElementRef>;
  @ViewChild('calendarRef') calendarRef!: ElementRef;

  calendarVos: CalendarVO[] = [];

  currentYear: number;
  resources: Resource[] = [];
  selectedMonth: number = 0;
  months: Month[] = [];

  holidays: Holiday[] = [];

  readonly dateFin = signal<Date | null>(null);
  readonly resource = model('');
  readonly dateSelectedDebut = model<Date | null>(null);
  readonly dialog = inject(MatDialog);

  hoveredRowIndex: number | null = null;
  hoveredColIndex: number | null = null;

  eventSpansMap: Map<string, Map<number, EventSpan[]>> = new Map();
  hoveredCell: { tableIdx: number; row: number; col: number } | null = null;
  showConge = true;
  showTeletravail = true;
  Math = Math;

  // isDarkMode = false;

  constructor(
    private holidayService: HolidayService,
    private resourceService: ResourceService,
    private calendarService: CalendarService,
    private overlayContainer: OverlayContainer
  ) {
    this.currentYear = new Date().getFullYear();
     this.overlayContainer.getContainerElement().classList.add('dark-mode');
  }

  ngOnInit() {
    this.initMonths();
    this.selectedMonth = this.getCurrentMonth();
    this.holidays = this.holidayService.getHolidays(this.currentYear);
    this.initResources();
  }

  getCurrentMonth(): number {
    return new Date().getMonth() + 1;
  }

  getDatesOfMonth(year: number, month: number): DateCalendar[] {
    return this.calendarService.getDatesOfMonth(year, month);
  }

    isResourceInactiveWholeMonth(resource: Resource, dates: DateCalendar[]): boolean {
    return this.calendarService.isResourceInactiveWholeMonth(resource, dates);
  }

  buildEventSpans(): void {
    this.eventSpansMap = this.calendarService.buildEventSpans(this.calendarVos, this.activeResources);
  }

  initMonths() {
    this.months = [
      new Month(1, 'Janvier'),
      new Month(2, 'Février'),
      new Month(3, 'Mars'),
      new Month(4, 'Avril'),
      new Month(5, 'Mai'),
      new Month(6, 'Juin'),
      new Month(7, 'Juillet'),
      new Month(8, 'Aout'),
      new Month(9, 'Septembre'),
      new Month(10, 'Octobre'),
      new Month(11, 'Novembre'),
      new Month(12, 'Décembre'),
    ];
  }

  isVisible(eventType: string): boolean {
    if (eventType === 'conge') return this.showConge;
    if (eventType === 'teletravail') return this.showTeletravail;
    return true;
  }

  initResources(): void {
    this.resourceService.getResources().subscribe((x) => {
      this.resources = x;
      for (let resource of this.resources) {
        for (let event of resource.events) {
          event.dateDebutEvent = new Date(event.dateDebutEvent + 'T00:00:00');
          event.dateFinEvent = new Date(event.dateFinEvent + 'T00:00:00');
        }
      }
      this.updateMonthsOfCalendarVo();
    });
  }
  updateMonthsOfCalendarVo(): void {
    this.calendarVos = [];
    for (let i = 0; i < 3; i++) {
      // Gère le dépassement d'année
      const targetDate = new Date(this.currentYear, this.selectedMonth - 1 + i);
      const month = targetDate.getMonth() + 1;
      const year = targetDate.getFullYear();

      let mesdates = this.getDatesOfMonth(year, month);
      let calendarVo = new CalendarVO(
        month,
        formatDate(mesdates.at(0) as Date, 'MMMM', 'fr'),
        mesdates
      );
      this.calendarVos.push(calendarVo);
    }

    this.buildEventSpans();
  }

   subMonth() {
    this.selectedMonth--;
    if (this.selectedMonth === 0) {
      this.selectedMonth = 12;
      this.currentYear--;
    }
    this.updateMonthsOfCalendarVo();
  }

  addMonth() {
    this.selectedMonth++;
    if (this.selectedMonth === 13) {
      this.selectedMonth = 1;
      this.currentYear++;
    }
    this.updateMonthsOfCalendarVo();
  }

  onMonthChange(newValue: string) {
    this.selectedMonth = parseInt(newValue);
    this.updateMonthsOfCalendarVo();
  }

  openDialog(resource: Resource, dateDebutEvent: Date): void {
    this.resource.set(resource.prenomResource);
    const dialogRef = this.dialog.open(DialogEvent, {
      data: {
        dateFin: this.dateFin(),
        dateSelectedDebut: dateDebutEvent,
        isJournee: true,
        isApresMidi: false,
        isMatin: false,
        resource: this.resource(),
      },
      panelClass: 'custom-dialog',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) {
        let event = new Event();
        event.dateDebutEvent = dateDebutEvent;
        event.libelleEvent = 'test en live 1';
        event.dateFinEvent = result.dateSelected;
        event.developper = resource;
        event.isJournee = result.isJournee;
        event.isMatin = result.isMatin;
        event.isApresMidi = result.isApresMidi;
        this.saveNewEvent(event);
        this.updateMonthsOfCalendarVo();
      }
    });
  }

  saveNewEvent(event: Event) {
    this.resourceService.saveEvent(event).subscribe({
      next: (savedEvent) => {
        console.log('Event sauvegardé :', savedEvent);
        this.initResources();
      },
      error: (err) => {
        console.error('Erreur de sauvegarde :', err);
      },
    });
  }

  get activeResources(): Resource[] {
    if (this.calendarVos.length === 0) return [];
    const dates = this.calendarVos[0].dates;
    return this.resources.filter((resource) => !this.isResourceInactiveWholeMonth(resource, dates));
  }

  getEmptyDays(count: number): number[] {
  return Array(count).fill(0);
}

isSpanOnWeekend(span: EventSpan, dates: DateCalendar[]): boolean {
  if (!span.colspan || span.colspan < 1) return false;

  const startIdx = dates.findIndex(d => d.getTime() === span.date.getTime());

  for (let i = startIdx; i < startIdx + span.colspan && i < dates.length; i++) {
    const d = dates[i];
    if (!d.isWeekend() && !d.isHoliday()) {
      return false;
    }
  }

  return true;
}

getLastDayOfMonth(date: Date): number {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
}

  onMouseEnterCell(rowIndex: number, colIndex: number) {
    this.hoveredRowIndex = rowIndex;
    this.hoveredColIndex = colIndex;
  }

  onMouseLeaveCell() {
    this.hoveredRowIndex = null;
    this.hoveredColIndex = null;
  }

getPresenceDays(resource: any, tableIdx: number): number {
  const spans = this.eventSpansMap.get(resource.prenomResource)?.get(tableIdx) || [];
  let total = 0;
  for (const span of spans) {
    const date = span.date;
    const isNonWorkingDay = date.isWeekend() || date.isHoliday() || date.isInactif(resource);
    const isFullDayEvent = date.isEvent(resource) && !date.isDemiJourneeEvent(resource);
    const isHalfDayEvent = date.isDemiJourneeEvent(resource);

    if (!isNonWorkingDay && !isFullDayEvent) {
      total += isHalfDayEvent ? 0.5 : 1;
    }
  }
  return total;
}







  exportCalendarToPdf() {
  if (!this.calendarRef) {
    console.error('calendarRef not found');
    return;
  }

  const element = this.calendarRef.nativeElement;

  // Ajouter la classe d'export PDF
  element.classList.add('pdf-export');

  const options = {
    margin:       [5, 5, 5, 5],  // marges réduites en mm
    filename:     `calendrier_${this.currentYear}_${this.selectedMonth}.pdf`,
    image:        { type: 'jpeg', quality: 0.98 },
    html2canvas:  { scale: 2, logging: true, dpi: 192, letterRendering: true },
    jsPDF:        { unit: 'mm', format: 'a4', orientation: 'landscape' },
    pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] },
  };

  html2pdf()
    .set(options)
    .from(element)
    .save()
    .finally(() => {
      // Retirer la classe après génération PDF pour revenir au style normal
      element.classList.remove('pdf-export');
    })
    .catch((err: any) => {
      console.error('Erreur génération PDF', err);
      element.classList.remove('pdf-export');
    });
}



}

interface EventSpan {
  date: DateCalendar;
  colspan: number;
}





@Component({
  selector: 'dialog-event',
  templateUrl: 'dialogEvent.html',
  styleUrl: 'dialogEvent.css',
  standalone: true,
  imports: [
    MatDatepickerModule,
    MatCheckboxModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [
    provideNativeDateAdapter(),
    { provide: MAT_DATE_FORMATS, useValue: MAT_NATIVE_DATE_FORMATS },
  ],
})
export class DialogEvent {
  readonly dialogRef = inject(MatDialogRef<DialogEvent>);
  readonly data = inject<DialogData>(MAT_DIALOG_DATA);
  readonly date = new FormControl(new Date());

  constructor() {
    this.date.setValue(this.data.dateSelectedDebut);
    this.data.isJournee = true;
    this.data.isMatin = false;
    this.data.isApresMidi = false;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onOkClick(): void {
    const result = {
      dateSelected: this.date.value,  // exemple de valeur pour la date sélectionnée
      isJournee: this.data.isJournee,       // Ajout de la valeur de isJournee
      isMatin: this.data.isMatin,     // Ajout de la valeur de isJournee
      isApresMidi: this.data.isApresMidi       // Ajout de la valeur de isJournee
    };
    this.dialogRef.close(result);  // Passe les données de retour lors de la fermeture du dialogue
  }

}





export interface DialogData {
  resource: string;
  dateFin: Date;
  dateSelectedDebut: Date;
  isJournee: Boolean;
  isApresMidi: Boolean;
  isMatin: Boolean;
}


export class DateCalendar extends Date {

  holidays: Holiday[] = [];

  constructor(holidays: Holiday[], year: number, month: number, day: number) {
    super(year, month, day);
    this.holidays = holidays;
  }

  isWeekend(): boolean {
    return (this.getDay() === 6 || this.getDay() === 0);
  }

  isHoliday(): boolean {
    let result = false;
    for (let day of this.holidays) {
      if (this.toDateString() === day.date.toDateString()) {
        result = true;
      }
    }
    return result;
  }

  isEvent(resource: Resource): boolean {
  let result = false;
  const currentDate = new Date(this.getFullYear(), this.getMonth(), this.getDate());

  for (let event of resource.events) {
    if (event.dateDebutEvent != null && event.dateFinEvent != null) {
      const start = new Date(event.dateDebutEvent);
      const end = new Date(event.dateFinEvent);

      if (currentDate >= start && currentDate <= end) {
        result = true;
      }
    }
  }
  return result;
}

isDemiJourneeEvent(resource: Resource): boolean {
  const currentDate = new Date(this.getFullYear(), this.getMonth(), this.getDate());

  return resource.events.some(event => 
    event.dateDebutEvent && event.dateFinEvent &&
    currentDate >= new Date(event.dateDebutEvent) &&
    currentDate <= new Date(event.dateFinEvent) &&
    (event.isApresMidi || event.isMatin)
  );
}

isInactif(resource: Resource): boolean {
  const today = new Date(this.getFullYear(), this.getMonth(), this.getDate());
  today.setHours(0, 0, 0, 0); // supprime les heures
  const dateDebut = new Date(resource.dateDebut);
   dateDebut.setHours(0, 0, 0, 0); // idem
  const dateFin = new Date(resource.dateFin);
  dateFin.setHours(0, 0, 0, 0); // idem

  return today < dateDebut || today > dateFin;
}

getEventFor(resource: Resource): Event | null {
  const currentDate = new Date(this.getFullYear(), this.getMonth(), this.getDate());

  for (let event of resource.events) {
    if (event.dateDebutEvent && event.dateFinEvent) {
      const start = new Date(event.dateDebutEvent);
      const end = new Date(event.dateFinEvent);

      if (currentDate >= start && currentDate <= end) {
        return event;
      }
    }
  }
  return null;
}



}



