import { Routes } from '@angular/router';
import { SprintListComponent } from './sprint-list/sprint-list.component';
import { BurnupChartComponent } from './burnup-chart/burnup-chart.component';
import { CalendarComponent } from './calendar/calendar.component';

export const routes: Routes = [
  // { path: '', loadComponent: () => import('./home/home.component').then(m => m.HomeComponent)},
    { path: 'sprints', loadComponent: () => import('./sprint-list/sprint-list.component').then(m => m.SprintListComponent)   },
   { path: 'sprint/:id/:name/burnup', component: BurnupChartComponent },
   { path: 'calendar', component: CalendarComponent }
];
