import { BurnupData } from "../service/burnup.service";

export interface SprintInfo {
  id: number;
  name: string;
  state: string;
  startDate?: string;
  endDate?: string;
  completeDate?: string;
  originBoardId?: string;
  burnupData : BurnupData;
}